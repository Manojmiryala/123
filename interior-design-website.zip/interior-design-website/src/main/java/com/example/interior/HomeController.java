package com.example.interior;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class HomeController {
    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/contact")
    public String contact(@RequestParam String name,
                          @RequestParam String email,
                          @RequestParam String message,
                          RedirectAttributes redirectAttributes) {
        // Demo form handler: connect a database or email service for permanent storage.
        redirectAttributes.addFlashAttribute("success",
                "Thank you, " + name + "! Your enquiry has been received.");
        return "redirect:/#contact";
    }
}
